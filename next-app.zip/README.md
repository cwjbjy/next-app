## 环境准备

Node 18.17+

## 开始

安装依赖

```bash
npm install
```

运行
```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```
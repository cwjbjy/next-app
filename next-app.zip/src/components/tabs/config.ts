export const menu = [
  {
    name: '首页',
    path: '/',
  },
  {
    name: '社会',
    path: '/society',
  },
  {
    name: '国内',
    path: '/inland',
  },
  {
    name: '国际',
    path: '/international',
  },
  {
    name: '娱乐',
    path: '/recreation',
  },
  {
    name: '体育',
    path: '/sports',
  },
  {
    name: '军事',
    path: '/military',
  },
];

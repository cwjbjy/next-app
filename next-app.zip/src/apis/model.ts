export interface New {
  url: string;
  thumbnail_pic_s: string;
  title: string;
}
